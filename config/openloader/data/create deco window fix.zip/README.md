## Fixes broken (due to empty tag) window(s) craft recipes.

![Telegram_DXMMOL2joJ](https://github.com/TheGiga/createdeco-window-crafts/assets/49173264/0a1eeb4a-38bd-4d39-86c8-15cb104a8776)
![image](https://github.com/TheGiga/createdeco-window-crafts/assets/49173264/a33c95cd-efd8-4feb-b914-8b938200b97b)

Following recipes were added:
```
createdeco:andesite_window
createdeco:copper_window
createdeco:iron_window
createdeco:industrial_iron_window
createdeco:brass_window
createdeco:zinc_window
```

This datapack will become deprecated, once the [issue](https://github.com/talrey/CreateDeco/issues/106) is fixed.
Alternatively, I suggest using something like KubeJS for more elegant fix, since i did the "brute-force" way by just adding alternative recipes.
